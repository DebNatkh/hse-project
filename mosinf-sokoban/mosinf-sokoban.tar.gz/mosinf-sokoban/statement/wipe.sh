#! /bin/bash
rm *.aux *.log *.pdf
